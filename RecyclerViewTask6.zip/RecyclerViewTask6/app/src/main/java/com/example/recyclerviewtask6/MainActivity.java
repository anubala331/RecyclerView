package com.example.recyclerviewtask6;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private List<Items> items =  new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Initialize();  // to initialize the recycler view
        AddListItems(); // to add items in list
        BindData(); // to bind picture and
    }

    private void Initialize()
    {
        recyclerView = findViewById(R.id.recycleproducts); //add recyclerview
    }

    private void AddListItems()
    {
        Items phone = new Items();
        phone.setPicture(R.drawable.mobile);
        phone.setProductname("1 - IPhone - 60$"); // add products
        items.add(phone);

        Items camera = new Items();
        camera.setPicture(R.drawable.camera);
        camera.setProductname("2 - Camera - 40$");
        items.add(camera);

        Items tv = new Items();
        tv.setPicture(R.drawable.tv);
        tv.setProductname("3 - TV - 200$");
        items.add(tv);

        Items usb = new Items();
        usb.setPicture(R.drawable.usb);
        usb.setProductname("4 - USB - 10$");
        items.add(usb);

        Items printer = new Items();
        printer.setPicture(R.drawable.printer);
        printer.setProductname("5 - Printer - 30$");
        items.add(printer);

        Items earphone = new Items();
        earphone.setPicture(R.drawable.earphone);
        earphone.setProductname("6 - Earphone - 5$");
        items.add(earphone);

        Items headphone = new Items();
        headphone.setPicture(R.drawable.headphone);
        headphone.setProductname("7 - Headphone - 25$");
        items.add(headphone);

        Items laptop = new Items();
        laptop.setPicture(R.drawable.laptop);
        laptop.setProductname("8 - Laptop - 1000$");
        items.add(laptop);

        Items speaker = new Items();
        speaker.setPicture(R.drawable.speakers);
        speaker.setProductname("9 - Speaker - 50$");
        items.add(speaker);

        Items mouse = new Items();
        mouse.setPicture(R.drawable.mouse);
        mouse.setProductname("10 - Mouse - 20$");
        items.add(mouse);

    }

    void BindData()
    {
        ListAdapter listAdapter;
        RecyclerView.LayoutManager layoutmanager = new LinearLayoutManager(MainActivity.this);
        recyclerView.setLayoutManager(layoutmanager);
        listAdapter = new ListAdapter(items, this);// bind products to recyclerview
        recyclerView.setAdapter(listAdapter);
        listAdapter.notifyDataSetChanged();
    }
}