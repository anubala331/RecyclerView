package com.example.recyclerviewtask6;

public class Items {
    private String productname; // items details
    private int picture;


    public int getPicture() {
        return picture;
    }

    public void setPicture(int picture) {
        this.picture = picture;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

}
