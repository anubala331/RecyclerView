package com.example.recyclerviewtask6;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    List<Items> items;
    public ListAdapter(List<Items> items, Context context)
    {
        super();
        this.items = items;// take all the products from list
    }

    class ViewHolder extends RecyclerView.ViewHolder
    {
        public TextView productname;

        public ImageView imageView;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            productname = (TextView) itemView.findViewById(R.id.textView2); //make container for products
            imageView = (ImageView) itemView.findViewById(R.id.imageView2);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.record_layout, parent, false); //make container for products
        ViewHolder viewholder = new ViewHolder(itemView);
        return viewholder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewholder, int position) {
        Items item = items.get(position);
        ((ViewHolder)viewholder).productname.setText(item.getProductname()); // bind the products
        ((ViewHolder)viewholder).imageView.setImageResource(item.getPicture());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
